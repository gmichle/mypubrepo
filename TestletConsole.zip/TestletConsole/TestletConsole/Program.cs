﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestletConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Item> itm = new List<Item>();
            itm.Add(new Item { ItemId = "1", ItemType = ItemTypeEnum.Pretest });
            itm.Add(new Item { ItemId = "2", ItemType = ItemTypeEnum.Pretest });
            itm.Add(new Item { ItemId = "3", ItemType = ItemTypeEnum.Pretest });
            itm.Add(new Item { ItemId = "4", ItemType = ItemTypeEnum.Pretest });
            itm.Add(new Item { ItemId = "5", ItemType = ItemTypeEnum.Operational });
            itm.Add(new Item { ItemId = "6", ItemType = ItemTypeEnum.Operational });
            itm.Add(new Item { ItemId = "7", ItemType = ItemTypeEnum.Operational });
            itm.Add(new Item { ItemId = "8", ItemType = ItemTypeEnum.Operational });
            itm.Add(new Item { ItemId = "9", ItemType = ItemTypeEnum.Operational });
            itm.Add(new Item { ItemId = "10", ItemType = ItemTypeEnum.Operational });
            Testlet obj = new Testlet("1", itm);
            itm = obj.Randomize();

            foreach (Item it in itm)
                Console.WriteLine("ItemId-{0} Item Type-{1}", it.ItemId, it.ItemType.ToString());

            Console.Read();
        }
    }
}
