﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestletConsole
{
    public class Testlet
    {
        public string TestletId;
        private List<Item> Items;

        public Testlet(string testletId, List<Item> items)
        {
            TestletId = testletId;
            Items = items;
        }

        public List<Item> Randomize()
        {
            //Items private collection has 6 Operational and 4 Pretest Items. Randomize the order of these items as per the requirement (with TDD)
            List<Item> Outtems = new List<Item>();
            //Add First 2 preset items
            var presetItem =  Items.Where(x => x.ItemType == ItemTypeEnum.Pretest).Select(i => i).ToList();
            Random rnd = new Random();
            int index1 = rnd.Next(presetItem.Count());
            int index2 = rnd.Next(presetItem.Count()-1);
            Outtems.Add(presetItem[index1]);
            presetItem.RemoveAt(index1);
            Outtems.Add(presetItem[index2]);
            presetItem.RemoveAt(index2);

            var opptItem = Items.Where(x => x.ItemType == ItemTypeEnum.Operational).Select(i => i).ToList();

            foreach (Item it in presetItem)
                opptItem.Add(it);

            var sufItem = ShuffleList<Item>(opptItem);        

            foreach (Item it in sufItem)
                Outtems.Add(it);

            return Outtems;
        }

        private List<E> ShuffleList<E>(List<E> inputList)
        {
            List<E> randomList = new List<E>();

            Random r = new Random();
            int randomIndex = 0;
            while (inputList.Count > 0)
            {
                randomIndex = r.Next(0, inputList.Count); //Choose a random object in the list
                randomList.Add(inputList[randomIndex]); //add it to the new, random list
                inputList.RemoveAt(randomIndex); //remove to avoid duplicates
            }

            return randomList; //return the new random list
        }
    }

    public class Item
    {
        public string ItemId;
        public ItemTypeEnum ItemType;

    }

    public enum ItemTypeEnum
    {
        Pretest = 0,
        Operational = 1
    }

}
