﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestletConsole;
using System.Linq;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        List<Item> Items;

        [TestMethod]
        public void Testlet_Count()
        {
            Assert.AreEqual(10, Items.Count);
        }

        [TestMethod]
        public void Testlet_FirstTwoPreset()
        {
            Assert.AreEqual(ItemTypeEnum.Pretest, Items[0].ItemType);
            Assert.AreEqual(ItemTypeEnum.Pretest, Items[1].ItemType);
        }
        [TestMethod]
        public void Testlet_OperationalCount()
        {
            Assert.AreEqual(6, Items.Where(x=>x.ItemType==ItemTypeEnum.Operational).Select(i=>i).ToList().Count());
        }

        [TestInitialize]
       public void InitializeTest()
        {
            List<Item> itm = new List<Item>();
            itm.Add(new Item { ItemId = "1", ItemType = ItemTypeEnum.Pretest });
            itm.Add(new Item { ItemId = "2", ItemType = ItemTypeEnum.Pretest });
            itm.Add(new Item { ItemId = "3", ItemType = ItemTypeEnum.Pretest });
            itm.Add(new Item { ItemId = "4", ItemType = ItemTypeEnum.Pretest });
            itm.Add(new Item { ItemId = "5", ItemType = ItemTypeEnum.Operational });
            itm.Add(new Item { ItemId = "6", ItemType = ItemTypeEnum.Operational });
            itm.Add(new Item { ItemId = "7", ItemType = ItemTypeEnum.Operational });
            itm.Add(new Item { ItemId = "8", ItemType = ItemTypeEnum.Operational });
            itm.Add(new Item { ItemId = "9", ItemType = ItemTypeEnum.Operational });
            itm.Add(new Item { ItemId = "10", ItemType = ItemTypeEnum.Operational });
            Testlet obj  = new Testlet("1", itm);
            Items = obj.Randomize();
        }
    }
}
